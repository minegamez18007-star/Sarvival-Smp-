SurvivalSMP 2.0.0 — Paper 26.1.2

Target: Minecraft 26.1.2 / Paper.
Java: 25.
Paper API: 26.1.2.build.74-stable.

Features:
- /shop professional single shop
- economy: /bal, /money, /sell, /sellall
- playtime rewards
- /playtime and /leaderboard
- sidebar scoreboard
- 4 custom weapons: Wind Katana, Thunder Hammer, Vampire Dagger, Demon Slayer Katana
- custom weapons available through shop and OP /giveweapon
- structured CustomModelData component for 26.1.x

The source is prepared for Paper 26.1.2. A final binary JAR must be compiled with JDK 25 against the Paper API.
